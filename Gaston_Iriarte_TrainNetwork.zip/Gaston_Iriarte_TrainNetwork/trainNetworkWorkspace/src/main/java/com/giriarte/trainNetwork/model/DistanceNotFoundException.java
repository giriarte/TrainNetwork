package com.giriarte.trainNetwork.model;

public class DistanceNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7688966318943960036L;

}
