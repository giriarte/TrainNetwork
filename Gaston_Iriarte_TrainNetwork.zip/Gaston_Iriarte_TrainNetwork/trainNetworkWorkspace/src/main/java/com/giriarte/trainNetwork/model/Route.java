package com.giriarte.trainNetwork.model;

public class Route {

	private String routeIndication;
	private Integer routeLength;
	
	public String getRouteIndication() {
		return routeIndication;
	}
	public void setRouteIndication(String routeIndication) {
		this.routeIndication = routeIndication;
	}
	public Integer getRouteLength() {
		return routeLength;
	}
	public void setRouteLength(Integer routeLength) {
		this.routeLength = routeLength;
	}
	
}
